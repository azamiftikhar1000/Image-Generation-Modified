mkdir datasets/
mkdir checkpoints/
mkdir results/
