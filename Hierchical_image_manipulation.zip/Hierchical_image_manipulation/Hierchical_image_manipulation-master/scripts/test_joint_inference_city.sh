python vis_joint_inference.py --gpu 0
